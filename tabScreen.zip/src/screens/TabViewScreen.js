import React, { Component } from "react";
import { View, StyleSheet, Text, TouchableOpacity, Image } from "react-native";
import { Icon, Content, Badge } from "native-base";
import BoxView from "./BoxView";
import CardView from "./CardView";

class SplashScreen extends Component {
  render() {
    return (
      <React.Fragment>
        <View style={styles.Container}>
          <View style={styles.containerView}>
            <View style={styles.view1}>
              <View style={styles.marginTop}></View>
              <View style={styles.EEView}>
                <Text style={styles.EEText}>E E</Text>
              </View>
              <View style={styles.gapBetween}></View>
              <View style={styles.IconView}>
                <TouchableOpacity style={styles.IconButton}>
                  <Image
                    style={styles.IconImage}
                    source={require("../icons/house.png")}
                  ></Image>
                </TouchableOpacity>
              </View>
              <View style={styles.gapBetween}></View>
              <View style={styles.IconView}>
                <TouchableOpacity>
                  <Image
                    style={styles.IconImage}
                    source={require("../icons/edit.png")}
                  ></Image>
                </TouchableOpacity>
              </View>
              <View style={styles.gapBetween}></View>
              <View style={styles.IconView}>
                <TouchableOpacity>
                  <Image
                    style={styles.IconCircle}
                    source={require("../icons/time.png")}
                  ></Image>
                </TouchableOpacity>
              </View>
              <View style={styles.gapBetween}></View>
              <View style={styles.IconView}>
                <TouchableOpacity>
                  <Image
                    style={styles.IconImage}
                    source={require("../icons/deadline.png")}
                  ></Image>
                </TouchableOpacity>
              </View>
              <View style={styles.gapBetween}></View>
              <View style={styles.IconView}>
                <Image
                  style={styles.IconImage}
                  source={require("../icons/user.png")}
                ></Image>
              </View>
            </View>
            <View style={styles.view2}>
              <View style={styles.marginTop}></View>
              <Content>
                <View style={styles.orderTextView}>
                  <Text style={styles.orderText}>Orders</Text>
                </View>
                <BoxView dataValue={1} />
                <BoxView dataValue={1} />
                <BoxView dataValue={0.65} />
                <BoxView dataValue={0.65} />
                <BoxView dataValue={0.65} />
                <BoxView dataValue={0.4} />
                <BoxView dataValue={0.4} />
                <BoxView dataValue={0.4} />
                <BoxView dataValue={0.4} />
              </Content>
            </View>
            <View style={styles.view3}>
              <View style={styles.boxView}>
                <CardView />
              </View>
              <View style={styles.bottomTabView}>
                <View
                  style={{
                    flex: 1,
                    backgroundColor: "white",
                    justifyContent: "flex-end",
                    alignItem: "flex-end",
                    paddingLeft: 30
                  }}
                >
                  <Text style={{ fontSize: 10 }}>
                    Order queue Next waiting to Accept
                  </Text>
                </View>
                <View style={{ height: 10 }}></View>
                <View
                  style={{
                    flex: 1,
                    backgroundColor: "white",
                    flexDirection: "row",
                    paddingLeft: 30
                  }}
                >
                  <Badge style={styles.bigBadge}>
                    <Text style={styles.bigBadgeText}>1</Text>
                  </Badge>
                  <View style={{ width: 8 }}></View>
                  <Badge style={styles.bigBadge}>
                    <Text style={styles.bigBadgeText}>2</Text>
                  </Badge>
                  <View style={{ width: 8 }}></View>
                  <Badge style={styles.bigBadge}>
                    <Text style={styles.bigBadgeText}>3</Text>
                  </Badge>
                  <View
                    style={{
                      flex: 1,
                      flexDirection: "row",
                      backgrpoundColor: "green",
                      alignItems: "flex-end",
                      justifyContent: "flex-end",
                      paddingRight: 13
                    }}
                  >
                    <Badge style={styles.onlineStatus}>
                      <View
                        style={{
                          flex: 1,
                          flexDirection: "row",
                          backgrpoundColor: "green",
                          alignItems: "flex-end",
                          justifyContent: "flex-end"
                        }}
                      >
                        <View
                          style={{
                            backgroundColor: "#d93f52",
                            height: 15,
                            alignSelf: "center"
                          }}
                        ></View>
                        <View style={styles.onlineStatusView}></View>
                        <Text style={styles.onlineText}>Online</Text>
                      </View>
                    </Badge>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </View>
      </React.Fragment>
    );
  }
}
export default SplashScreen;

styles = StyleSheet.create({
  Container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#e9404e"
  },
  IconView: {
    height: 50,
    justifyContent: "center",
    alignItems: "center"
  },
  Icon: {
    color: "#ec7b8f"
  },
  view1: {
    flex: 1,
    backgroundColor: "#e9404e"
  },
  view2: {
    flex: 4,
    backgroundColor: "white",
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20,
    shadowColor: "#000",
    shadowOffset: { width: 2, height: 2 },
    shadowColor: "gray",
    shadowOpacity: 0.6,
    zIndex: 999
  },
  IconButton: {
    backgroundColor: "#ea5f75",
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 7
  },
  view3: {
    flex: 5,
    backgroundColor: "#fcf6f6"
  },
  bigBadge: {
    height: 20,
    width: 20,
    borderRadius: 25,
    justifyContent: "flex-start",
    alignItems: "center",
    borderColor: "#e94046",
    backgroundColor: "white",
    borderWidth: 1
  },

  onlineStatus: {
    height: 20,
    borderRadius: 25,
    justifyContent: "flex-end",
    alignItems: "flex-end",
    borderColor: "#65ce83",
    backgroundColor: "white",
    borderWidth: 1
  },
  bigBadgeText: {
    alignSelf: "center",
    fontSize: 12,
    color: "#e94046"
  },
  onlineText: {
    alignSelf: "center",
    fontSize: 10,
    color: "#65ce83"
  },
  containerView: {
    flex: 1,
    flexDirection: "row"
  },
  gapBetween: {
    height: 20
  },
  EEView: {
    height: 30,
    justifyContent: "center",
    alignItems: "center"
  },
  EEText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 23
  },
  marginTop: {
    height: 35,
    justifyContent: "center",
    alignSelf: "center"
  },
  orderTextView: {
    height: 30,
    justifyContent: "center",
    paddingLeft: 20
  },
  IconImage: {
    width: 30,
    height: 34
  },
  IconCircle: {
    width: 34,
    height: 34
  },
  orderText: {
    color: "black",
    fontSize: 23
  },
  boxView: {
    flex: 8,
    justifyContent: "center",
    padding: 30
  },
  bottomTabView: {
    flex: 1,
    backgroundColor: "white"
  },
  onlineStatusView: {
    width: 6,
    height: 6,
    backgroundColor: "#65ce83",
    borderRadius: 30,
    alignSelf: "center"
  }
});
